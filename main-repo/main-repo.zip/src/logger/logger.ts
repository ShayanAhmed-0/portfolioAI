import pino from "pino";
import pretty from "pino-pretty";
const stream = pretty({
  colorize: true,
});

export default pino({ level: "info" }, stream);
