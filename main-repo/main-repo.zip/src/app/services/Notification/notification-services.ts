// import { prismaClient } from "../../../lib/db";
// import { gethashedPass } from "../../../utils/generate-hash";
// import { generateSalt } from "../../../utils/generate-salt";

// export default class NotificationService {
//   public static newNotification(
//     title: string,
//     description: string,
//     userProfileId: string,
//     vendorProfileId: string
//   ) {
//     return prismaClient.notification.create({
//       data: {
//         title,
//         description,
//         userProfileId,
//         vendorProfileId,
//       },
//     });
//   }
// }
